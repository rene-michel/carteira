<?php
//session_id('6f5kii2hsp82kpaugtk4src6t0');
$sessao=session_id();

	session_start();
echo 'id: '.$_SESSION['id'].'<br>'.'tipo: '.$_SESSION['tipo'].'<br>';
echo "SID: ".SID."<br>session_id(): ".session_id()."<br>COOKIE: ".$_COOKIE["PHPSESSID"];
?>

<html>
<script type="text/javascript">
	function session_id() {
		return /SESS\w*ID=([^;]+)/i.test(document.cookie) ? RegExp.$1 : false;
	}
	function getPHPSessId() {
    var phpSessionId = document.cookie.match(/PHPSESSID=[A-Za-z0-9]+\;/i);

    if(phpSessionId == null) 
        return '';

    if(typeof(phpSessionId) == 'undefined')
        return '';

    if(phpSessionId.length <= 0)
        return '';

    phpSessionId = phpSessionId[0];

    var end = phpSessionId.lastIndexOf(';');
    if(end == -1) end = phpSessionId.length;

    return phpSessionId.substring(10, end);
}
	document.write('<br>via javascript: '+session_id()+'<br>');
</script>

</html>