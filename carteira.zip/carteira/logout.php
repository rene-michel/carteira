<?
	session_start();
	$_SESSION['id'] = null;
	unset($_SESSION['id']);
	$_SESSION=array();
	session_destroy();
	echo "saindo...";
?>