<?
session_start();

function logado()
{
  if (isset($_SESSION['id']) && is_numeric($_SESSION['id']))
    return true;
  return false;
}


?>
